<?php
    require('./database.php');

    if (isset($_POST['withStocks'])) {
        
        $queryWithStocks = "SELECT * FROM products WHERE quantity > 1";
        $sqlReadProduct = mysqli_query($connection, $queryWithStocks);
    }


?>