<?php 

    require('./database.php');

    $queryWithStocks = "SELECT * FROM product";
    $sqlWithStocks = mysqli_query($connection, $queryWithStocks);

    echo "<script> window.location.href='/php/App.php' </script>";

?>