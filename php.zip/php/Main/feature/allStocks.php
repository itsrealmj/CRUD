<?php 
    require('./database.php');

    $queryAllProduct = "SELECT * FROM product";
    $sqlAllProduct = mysqli_query($connection, $queryAllProduct);

?>