<?php 
    require('../database.php');

    if(isset($_POST['create'])) {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $category = $_POST['category'];

        // 
        $queryCreate = "INSERT INTO products 
                            (name, description, price, quantity, category) 
                        VALUES 
                            ('$name','$description','$price','$quantity','$category')";
        $sqlCreate = mysqli_query($connection, $queryCreate);
    
        echo "<script> window.location.href='/php/App.php' </script>";
    }

    

    

?>