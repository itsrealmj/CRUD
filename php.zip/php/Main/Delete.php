<?php 
    require('../database.php');

    if (isset($_POST['deleteBtn'])) {
        $idDelete = $_POST['deleteBtn'];

        $queryDelete = "DELETE FROM product WHERE id = $idDelete";
        $sqlDelete = mysqli_query($connection, $queryDelete);

        echo "<script> window.location.href='/php/App.php' </script>";
    }    

?>