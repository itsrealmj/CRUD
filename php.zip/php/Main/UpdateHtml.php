
<?php 
    require('../database.php');

    if (isset($_POST['editBtn'])) {
        $idEditBtn = $_POST['editBtn'];
        
        $editName = $_POST['editName'];
        $editDescription = $_POST['editDescription'];
        $editPrice = $_POST['editPrice'];
        $editQuantity = $_POST['editQuantity'];
        $editCategory = $_POST['editCategory'];
    
        $sqlEdit = "SELECT * FROM products WHERE id = '$idEditBtn'";
        $queryEdit = mysqli_query($connection, $sqlEdit);
    }

    if (isset($_POST['updateBtn'])) {
        $Uid = $_POST['updateBtn'];

        $updateName = $_POST['updateName'];
        $updateDescription = $_POST['updateDescription'];
        $updatePrice = $_POST['updatePrice'];
        $updateQuantity = $_POST['updateQuantity'];
        $updateCategory = $_POST['updateCategory'];

        $queryUpdate = "UPDATE products 
                            SET 
                                name= '$updateName' , 
                                description= '$updateDescription' , 
                                price= '$updatePrice' , 
                                quantity= '$updateQuantity' , 
                                category= '$updateCategory'
                            WHERE id = $Uid ";

        $sqlUpdate = mysqli_query($connection, $queryUpdate);
        
        echo "<script> window.location.href='/php/App.php' </script>";
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Update Section</title>
</head>
<body>
	<div class="form-container-update"> 

        <span class="closed-form-btn"> <a href="/php/App.php"> <img  src="../img/close.png" width="30px"> </a> </span>
        <h4 style="text-align: center; color: rgba(0, 0, 0, .6);">EDIT PRODUCT</h4>

        <form action="./UpdateHtml.php" method="post" >

            <label>Name <span class="asterisk">*</span></label>
            <input type="text" name="updateName" value="<?php echo $editName ?>" autocomplete="off" required>

            <label>Description <span class="asterisk">*</label>
            <input type="text" name="updateDescription" value="<?php echo $editDescription ?>" autocomplete="off" required>

            <label>Price <span class="asterisk">*</label>
            <input type="number" name="updatePrice" value="<?php echo $editPrice ?>" autocomplete="off" required>

            <label>Quantity <span class="asterisk">*</label>
            <input type="number" name="updateQuantity" value="<?php echo $editQuantity ?>" autocomplete="off" required>

            <label>Category <span class="asterisk">*</label>
            <input type="text" name="updateCategory" value="<?php echo $editCategory ?>" autocomplete="off" required>

            <button type="submit" name="updateBtn" value="<?php echo $idEditBtn ?>" >Update</button>
        </form>
    </div>
</body>
</html>