<?php 
    require('./database.php');

    $queryReadProduct = "SELECT * FROM products";
    $sqlReadProduct = mysqli_query($connection, $queryReadProduct);

?>
