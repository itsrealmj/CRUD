<?php 
    require('./database.php');

    $queryReadProduct = "SELECT * FROM product";
    $sqlReadProduct = mysqli_query($connection, $queryReadProduct);

?>
