<?php 
    require('../database.php');
    // echo "<script> window.location.href='/php/Read.php' </script>";
    if (isset($_POST['noStock'])) {
        // $noStock = $_POST['noStock'];

        $queryZero = "SELECT * FROM product WHERE quantity = 0";
        $sqlReadProduct = mysqli_query($connection, $queryZero);

        while($results = mysqli_fetch_array($sqlReadProduct)) {
        ?>
            <tr>
                <td> <?php echo $results['name'] ?> </td>
                <td> <?php echo $results['description'] ?> </td>
                <td> <?php echo $results['price'] ?> </td>
                <td> <?php echo $results['quantity'] ?> </td>
                <td> <?php echo $results['category'] ?> </td>

                <td class="tbl-btns">
                    <form action="/PHP/Main/UpdateHtml.php" method="post">
						<input type="hidden" name="editName" value="<?php echo $results['name'] ?>">
						<input type="hidden" name="editDescription" value="<?php echo $results['description'] ?>">
						<input type="hidden" name="editPrice" value="<?php echo $results['price'] ?>">
						<input type="hidden" name="editQuantity" value="<?php echo $results['quantity'] ?>">
						<input type="hidden" name="editCategory" value="<?php echo $results['category'] ?>">
                        <button class="tbl-btns tbl-edit-btn" type="submit" name="editBtn" value="<?php echo $results['id'] ?>">Edit</button>
                    </form>
                    <form action="./Main/Delete.php" method="post">
                        <button class="tbl-btns tbl-delete-btn" type="submit" name="deleteBtn" value="<?php echo $results['id'] ?>" >Delete</button>
                    </form>
                </td>
            </tr> 
        <?php } 
        
    }    
    
        
?>