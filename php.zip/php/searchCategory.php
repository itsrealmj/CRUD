<?php
    require('./database.php');

    if (isset($_POST['search'])) {
        $categoryName = $_POST['categoryName'];
        
        $queryCategory = "SELECT * FROM products WHERE category = '$categoryName' ";
        $sqlReadProduct = mysqli_query($connection, $queryCategory); 
    } 
  
?>