<?php
    require('./database.php');

    if (isset($_POST['noStock'])) {

        $queryZero = "SELECT * FROM products WHERE quantity = 0";
        $sqlReadProduct = mysqli_query($connection, $queryZero);
    }

?>