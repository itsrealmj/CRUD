

// CREATE PRODUCT SECTION START
const createProductBtn = document.querySelector('.create-product-btn')
const closedFormBtn = document.querySelector('.closed-form-btn')

createProductBtn.addEventListener('click', () => {
	document.querySelector('.form-container').classList.add('active')
})
closedFormBtn.addEventListener('click', () => {
	document.querySelector('.form-container').classList.remove('active')
})
// CREATE PRODUCT SECTION END

// UPDATE EDIT PRODUCT START
const updateProductBtn = document.querySelector('.tbl-edit-btn')
const closedUpdateFormBtn = document.querySelector('.closed-update-form-btn')

updateProductBtn.addEventListener('click', () => {
	document.querySelector('.form-container-update').classList.add('active')
})
closedUpdateFormBtn.addEventListener('click', () => {
	document.querySelector('.form-container-update').classList.remove('active')
})
// UPDATE EDIT PRODUCT END
