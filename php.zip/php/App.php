<?php
    require('./Main/Read.php'); 
    require('./zeroStock.php'); 
    require('./withStocks.php'); 
    require('./searchCategory.php'); 
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>

<header>
	<section class="header-section">
		<h2>SIMPLE CRUD OF PRODUCTS</h2>
		<button class="create-product-btn">Create product</button>
	</section>
</header>


<div class="form-container"> 
	<span class="closed-form-btn"> <img  src="./img/close.png" width="30px"></span>
	<h4 style="text-align: center; color: rgba(0, 0, 0, .6);">ADD NEW PRODUCT</h4>

	<form action="/php/Main/Create.php" method="post">
		<label>Name <span class="asterisk">*</span></label>
		<input type="text" name="name" autocomplete="off" required>

		<label>Description <span class="asterisk">*</label>
		<input type="text" name="description" autocomplete="off" required>

		<label>Price <span class="asterisk">*</label>
		<input type="number" name="price" autocomplete="off" required>

		<label>Quantity <span class="asterisk">*</label>
		<input type="number" name="quantity" autocomplete="off" required>

		<label>Category <span class="asterisk">*</label>
		<input type="text" name="category" autocomplete="off" required>

		<button type="submit" name="create" >Add</button>
	</form>
</div>

<div class="search-section">
	<div class="search-input">	
		<form action="/php/App.php" method="post">
			<input type="text" name="categoryName" placeholder="search by category" autocomplete="off">
			<button type="submit" name="search" >Search</button>
		</form>
	</div>
	<div class="filter-btns">
		<form action="/php/App.php" method="post">
			<button class="with-stock-btn">All stocks</button>
		</form>
		<form action="/php/App.php" method="post">
			<button class="with-stock-btn" name="withStocks" >With stocks</button>
		</form>
		<form action="/php/App.php" method="post">
			<button class="no-stock-btn" type="submit" name="noStock" value="0">No stock</button>
		</form>
	</div>
</div>

    <section class="main-section">
		<table>
		  <tr>
		    <th>Name</th>
		    <th>Description</th>
		    <th>Price</th>
		    <th>Quantity</th>
		    <th>Category</th>
		    <th>Action</th>
		  </tr>

        <?php while($results = mysqli_fetch_array($sqlReadProduct)) { ?>
            <tr>
                <td> <?php echo $results['name'] ?> </td>
                <td> <?php echo $results['description'] ?> </td>
                <td> <?php echo $results['price'] ?> </td>
                <td> <?php echo $results['quantity'] ?> </td>
                <td> <?php echo $results['category'] ?> </td>

                <td class="tbl-btns">
                    <form action="/PHP/Main/UpdateHtml.php" method="post">
						<input type="hidden" name="editName" value="<?php echo $results['name'] ?>">
						<input type="hidden" name="editDescription" value="<?php echo $results['description'] ?>">
						<input type="hidden" name="editPrice" value="<?php echo $results['price'] ?>">
						<input type="hidden" name="editQuantity" value="<?php echo $results['quantity'] ?>">
						<input type="hidden" name="editCategory" value="<?php echo $results['category'] ?>">
                        <button class="tbl-btns tbl-edit-btn" type="submit" name="editBtn" value="<?php echo $results['id'] ?>">Edit</button>
                    </form>
                    <form action="./Main/Delete.php" method="post">
                        <button class="tbl-btns tbl-delete-btn" type="submit" name="deleteBtn" value="<?php echo $results['id'] ?>" >Delete</button>
                    </form>
                </td>
            </tr> 
        <?php } ?>
		   
		</table>
    </section>



    <script src="index.js"></script>
</body>
</html>