<?php 
$host = "localhost";
$user = "root";
$password = "password";
$database = "db";

$connection = mysqli_connect($host, $user, $password, $database);


if (mysqli_connect_error()) {
    echo "Error : Can't connect to database";
    echo mysqli_connect_error() ;
} else {
    // echo "Sucessfully connected to database !";
}

?>