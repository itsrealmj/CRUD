
<div class="col-md-12">
  <div class="form-group">
    <div class="row">
      <div class="col-md-3">
        <div class="form-group has-feedback">
          <label>Region <b style="color: red">*</b></label>                    
          <select name="user_region" id="region" class="form-control x" <?= $visible ?>>
            <option disabled="" selected=""><?= $r ?></option>
            <option value="">--- REGION ---</option>
          </select>
        </div>
      </div>
      <div class="col-md-3">
        <div class="form-group has-feedback">
          <label>Province <b style="color: red">*</b></label>                    
          <select name="user_province" id="province" class="form-control x" <?= $visible ?>>
            <?php
              if(!empty($p)){
                ?>
                <option disabled="" selected=""><?= $p ?></option>
                <option value="">--- PROVINCE ---</option>
                <?php
              }else{
                ?>
                <option value="">--- PROVINCE ---</option>
                <?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-3">
        <div class="form-group has-feedback">
          <label>City/Municipality <b style="color: red">*</b></label>
          <select name="user_citymun" id="city" class="form-control x" <?= $visible ?>>
            <?php
              if(!empty($c)){
                ?>
                <option disabled="" selected=""><?= $c ?></option>
                <option value="">--- CITY ---</option>
                <?php
              }else{
                ?>
                <option value="">--- CITY ---</option>
                <?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-3">
        <div class="form-group has-feedback">
          <label>Barangay <b style="color: red">*</b></label>
          <select name="user_barangay" id="barangay" class="form-control x" <?= $visible ?>>
            <?php
              if(!empty($b)){
                ?>
                <option disabled="" selected=""><?= $b ?></option>
                <option value="">--- BRGY ---</option>
                <?php
              }else{
                ?>
                <option value="">--- BRGY ---</option>
                <?php
              }
            ?>
          </select>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="assets/dist/js/jquery.js"></script>
<script type="text/javascript" src="assets/dist/js/jquery.ph-locations.js"></script>