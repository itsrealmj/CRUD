exports.login = function () {

}

exports.logut = function () {
	
}

exports.register = function () {
	
}

exports.home = function (req, res) {
	res.render('home')
}