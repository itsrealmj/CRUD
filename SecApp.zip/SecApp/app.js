const express = require('express')

const bodyParser = require('body-parser')
const ejs = require('ejs')

const app = express()

const router = require('./router')

app.set('view engine', 'ejs')
app.use('/', router)
app.use(express.static('public'))
app.use(bodyParser.urlencoded({extended : true}))








const port = 3000
app.listen(port, () => {
	console.log(`App running on port ${port}`)
})