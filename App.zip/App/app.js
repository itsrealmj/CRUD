const express = require('express')
const bodyParser = require('body-parser')
const ejs = require('ejs')

const app = express()
app.set('view engine', 'ejs')

app.use(express.json())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended : true}))
app.use(express.static('public'))

const mysql = require('mysql')

const con = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "password",
	database: "mydb",
});


// SEARCH CATEGORY FUNCTION
let searchCategory
app.post('/searches', (req, res) => {
	let search = req.body.searchName
	
	searchCategory = search

	res.redirect('/searches')
})

// DISPLAY ALL ADDED PRODUCTS START
app.get('/', (req, res) => {
	con.connect((err) => {
		con.query("SELECT * FROM products", (err, results, fields) => {
		  res.render('home', { datas : results })
		}) 
	})
})


app.post('/', (req, res) => {
	const {name, description, price, quantity, category} = req.body

	con.connect( (err) => {	
		var sql = `INSERT INTO products (name, description, price, quantity, category) VALUES ('${name}','${description}','${price}','${quantity}','${category}')`;
		con.query(sql, (err, result) => {
			
		  if (err) throw err;
		});
	});
	  res.redirect('/')
})

// DISPLAY ALL ADDED PRODUCTS END

app.get('/searches', (req, res) => {
	con.connect((err) => {
		con.query(`SELECT * FROM products WHERE category = '${searchCategory}'`, (err, results, fields) => {
			res.render('home', { datas : results } )
		}) 
	})
})

// SEARCH CATEGORY FUNCTION END


// WITH STOCKS FUNCTION START
app.get('/withstock', (req, res) => {
	con.connect((err) => {
		con.query("SELECT * FROM products WHERE quantity >= 1", (err, results, fields) => {
			res.render('home', { datas : results })
		}) 
	})
})
// WITH STOCKS FUNCTION END

// NO STOCKS FUNCTION START
app.get('/nostock', (req, res) => {
	con.connect((err) => {
		con.query("SELECT * FROM products WHERE quantity = 0", (err, results, fields) => {
			res.render('home', { datas : results })
		}) 
	})
	
})
// NO STOCKS FUNCTION END



// DELETE ROW PRODUCT FROM TABLE FUNCTION START
app.post('/delete', (req, res) => {
	const deleteBtn = req.body.deleteBtn

	con.connect((err) => {
		var sql = `DELETE FROM products WHERE id = '${deleteBtn}'`;
		con.query(sql,(err, result) => {
		  if (err) throw err;
		});
	  });
	  res.redirect('/')
})
// DELETE ROW PRODUCT FROM TABLE FUNCTION END



// UPDATE SELECTED PRODUCT FROM TABLE FUNCTION START
let data 
app.post('/update', (req, res) => {
	let id  = req.body.editBtn
	
	con.connect((err) => {
		var sql = `SELECT * FROM products WHERE id = '${id}'`;
		con.query(sql, (err, result) => {
			data = result
			
		  if (err) throw err;
		});
	  });
	res.redirect('/update')	
})

app.get('/update', (req, res) => {

	res.render('update', {data : data})
})
// UPDATE SELECTED PRODUCT FROM TABLE FUNCTION START



// 


const port = 3000
app.listen(port, () => {
	console.log(`App running on port ${port}`)
})
