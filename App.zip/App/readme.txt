(Can't create dynamic table yet)

CREATE TABLE products (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255),  description VARCHAR(255), price int, quantity int, category VARCHAR(255)) 