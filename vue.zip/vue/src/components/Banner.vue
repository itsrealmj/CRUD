<template>
	<section class="banner-section">
      <aside>
        <ul>
          <li><a href="#">Products One</a></li>
          <li><a href="#">Products Two</a></li>
          <li><a href="#">Products Three</a></li>
          <li><a href="#">Products Four</a></li>
          <li><a href="#">Products Five</a></li>
          <li><a href="#">Products Six</a></li>
          <li><a href="#">Products Seven</a></li>
        </ul>
      </aside>
      <div class="promo-section">
        <img src="../assets/banner.jpg">
      </div>
    </section>
</template>

<style>
	.banner-section {
		margin:1rem auto 0;
		display:flex;
		gap:1%;
		width:90%;
		height:350px;
    }
	.banner-section aside {
		background : #f1f1f1;
		padding:.5rem 1rem;
		border-radius:5px;
		width:200px;
	}
	aside ul {
		list-style:none;
		line-height:2.5rem;
	}
	aside ul li a {
		color:rgba(0,0,0, .7);
		font-weight:600;
		text-decoration : none;
		position: relative;
	}
	aside ul li a::after {
		content: "";
    position: absolute;
    bottom: -.5rem;
    left: 0;
    height: 3px;
    width: 0;
    background-color: red;
    transition: .3s ease-in-out;
	}
	aside ul li a:hover::after {
		width: 100%;
    background-color: rgba(255, 68, 0, 0.775);

	}
	.banner-section .promo-section {
		width:100%;

	}
	.banner-section .promo-section img {
		width:100%;
		height:100%;
		border-radius:5px;
	}


</style>