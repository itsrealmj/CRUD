<template>
	<header>
      <nav>
        <img src="../assets/images/logo.svg" alt="logo" />
        <div class="form-section">
			<form>
			  <input type="text" name="categoryName" placeholder="Search for category">
			  <button type="submit">Search</button>
			</form>
		</div>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Products</a></li>
        </ul>
      </nav>
    </header>
</template>

<style>

	header {
		background-color : #f1f1f1;
		position:sticky;
		top:0;
		z-index:2;
	}
	header nav {

		display:flex;
		justify-content:space-between;
		align-items:center;
		padding:1rem 5rem;

	}
	header nav ul {
		display:flex;
		gap:1rem;
		list-style:none;
		
	}
	header nav ul li a {
		text-decoration:none;
		position:relative;
		color:rgba(0,0,0, .7);
		font-weight:600;

	}
	header nav ul li a::after {
		content: "";
	    position: absolute;
	    bottom: -.5rem;
	    left: 0;
	    height: 3px;
	    width: 0;
	    background-color: red;
	    transition: .3s ease-in-out;
	}
	header nav ul li a:hover::after {
		width: 100%;
	}

	.form-section {
		margin-left:5rem;
		width:70%;
	}
	.form-section input {
		width:80%;
		padding:.5rem .7rem;
		border:none;
		font-size : 1rem;
		border-radius:5px;
		border:1px solid rgba(255, 68, 0, 0.775);
		outline:none;
	}
	.form-section button {
		width:10%;
		margin:5px;
		padding:.5rem .7rem;
		background-color: rgba(255, 68, 0, 0.775);
		color:#f1f1f1;
		font-weight:600;
		border:none;
		font-size : 1rem;
		border:1px solid rgba(255, 68, 0, 0.775);
		border-radius:5px;
	}
</style>