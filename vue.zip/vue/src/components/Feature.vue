<template>
	<section class="feature-section">
      <ul>
        <li>
          <img src="../assets/laptop.png" width="50px">
        </li>
        <li>
          <img src="../assets/phone.png" width="50px">
        </li>
        <li>
          <img src="../assets/speaker.png" width="50px">
        </li>
        <li>
          <img src="../assets/speaker.png" width="50px">
        </li>
        <li>
          <img src="../assets/phone.png" width="50px">
        </li>
        <li>
          <img src="../assets/laptop.png" width="50px">
        </li>
        <li>
          <img src="../assets/speaker.png" width="50px">
        </li>
        <li>
          <img src="../assets/speaker.png" width="50px">
        </li>
        <li>
          <img src="../assets/phone.png" width="50px">
        </li>
        <li>
          <img src="../assets/laptop.png" width="50px">
        </li>
        <li>
          <img src="../assets/speaker.png" width="50px">
        </li>
        <li>
          <img src="../assets/speaker.png" width="50px">
        </li>
        <li>
          <img src="../assets/phone.png" width="50px">
        </li>
        <li>
          <img src="../assets/laptop.png" width="50px">
        </li><li>
          <img src="../assets/speaker.png" width="50px">
        </li>
        
      </ul>
    </section>
</template>

<style>
	.feature-section ul {
		display:flex;
		text-align:center;
		align-items:center;
		list-style:none;
		justify-content:center;
	}
	.feature-section ul li {
		padding:5px 10px;
		margin:5px;
		
		cursor:pointer;
	}
	.feature-section ul li:hover {
		
		transition:.3s;
		transform:scale(1.05);
		box-shadow:1px 1px 10px 1px gray; 
	}

</style>