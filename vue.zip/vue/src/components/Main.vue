

<template>
	<section class="main-top-deal">
      <h1>Top Deals | Main Section</h1>
      <div>
        <figure>
          <img src="../assets/phone.png" />
          <figcaption>product One.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/laptop.png" />
          <figcaption>product Two.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/speaker.png" />
          <figcaption>product Three.</figcaption>
          <span>$123</span>
        </figure>
        <figure>
          <img src="../assets/phone.png" />
          <figcaption>product One.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/laptop.png" />
          <figcaption>product Two.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/speaker.png" />
          <figcaption>product Three.</figcaption>
          <span>$123</span>
        </figure>
        <figure>
          <img src="../assets/phone.png" />
          <figcaption>product One.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/laptop.png" />
          <figcaption>product Two.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/speaker.png" />
          <figcaption>product Three.</figcaption>
          <span>$123</span>
        </figure>
        <figure>
          <img src="../assets/phone.png" />
          <figcaption>product One.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/laptop.png" />
          <figcaption>product Two.</figcaption>
          <span>$123</span>
        </figure>

        <figure>
          <img src="../assets/speaker.png" />
          <figcaption>product Three.</figcaption>
          <span>$123</span>
        </figure>
      </div>
    </section>

</template>

<script>
  export default {
    data() {
      
    },
    components: {
      
    }
}
</script>


<style>
	.main-top-deal {
		margin-top:1rem;

	}
	.main-top-deal h1 {
		background : #f1f1f1;
		margin:1rem 4rem;
		padding:1rem;
	}
	.main-top-deal div {
		margin:1rem 4rem;
		
		display:flex;
		gap: 1.7rem;
		justify-content:flex-start;
		flex-wrap:wrap;

	}

	.main-top-deal figure {
		font-size:15px;
		padding: 1rem 1.5rem;
		cursor:pointer;

		transition:.2s ease-in-out;
	}
	.main-top-deal figure figcaption {
		margin:5px 0;
	}
	.main-top-deal figure span {
		font-weight:600;
	}
	.main-top-deal figure:hover {
		box-shadow: -5px 7px 10px -5px gray;
		transform:scale(1.01);
	}
	.main-top-deal div img {
		width:100px;
	}
	
</style>