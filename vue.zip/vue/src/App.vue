<script setup>
import Header from './components/Header.vue'
import Banner from './components/Banner.vue'
import Feature from './components/Feature.vue'

import TopDeal from './components/TopDeal.vue'
import Main from './components/Main.vue'
import Pagination from './components/Pagination.vue'
import Footer from './components/Footer.vue'

</script>

<template>
  <Header />
  <Search />
  <Banner />
  <Feature />

  <TopDeal />
  <Main />
  <Pagination />
  <Footer />

</template>
