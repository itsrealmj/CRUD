import { TestimonialArrayBtn, currentYear} from "./components/footer-year.js"
import { burgerIcon, closedIconMenu } from "./components/mobileMenu.js"




